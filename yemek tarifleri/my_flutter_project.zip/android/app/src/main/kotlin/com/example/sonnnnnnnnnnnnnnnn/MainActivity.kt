package com.example.sonnnnnnnnnnnnnnnn

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
